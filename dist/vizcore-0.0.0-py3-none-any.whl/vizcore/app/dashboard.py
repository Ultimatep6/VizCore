from .window import ApplicationWindow
from .mainloop import MainLoop
from ..bus.data_bus import DataBus
# from ..renderer.renderer import Renderer  # Uncomment when renderer is implemented
# from ..layout.grid_layout import GridLayout  # Uncomment when layout engine is implemented

class Dashboard:
    """
    Main entry point for building dashboards.

    Responsibilities:
        - Manage widget registration
        - Connect to telemetry data bus
        - Initialize renderer
        - Initialize layout engine
        - Start visualization loop

    Primary functionality:
        - Add widgets to layout
        - Bind widgets to telemetry signals
        - Control dashboard lifecycle
    """
    def __init__(self, width=800, height=600, title="VizCore Dashboard"):
        self.window = ApplicationWindow(width=width, height=height, title=title)
        self.data_bus = DataBus()
        # self.renderer = Renderer(self.window)  # Uncomment when renderer is implemented
        # self.layout_engine = GridLayout(self.window)  # Uncomment when layout engine is implemented
        self.widgets = []

    def add_widget(self, widget, signal=None):
        self.widgets.append(widget)
        if signal:
            widget.bind_signal(self.data_bus, signal)
        # Optionally add widget to layout engine here

    def run(self):
        # Optionally initialize renderer and layout engine here
        mainloop = MainLoop(self.window, self.widgets)
        mainloop.run()