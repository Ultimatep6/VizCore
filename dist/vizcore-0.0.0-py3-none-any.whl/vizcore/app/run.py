from window import ApplicationWindow
from renderer.renderer import Renderer
import pyglet
import moderngl
import numpy as np




class TriangleWidget:
    def __init__(self, ctx):
        # Vertex data for a triangle (x, y)
        vertices = np.array([
            -0.6, -0.6,
             0.6, -0.6,
             0.0,  0.6,
        ], dtype='f4')
        self.vbo = ctx.buffer(vertices.tobytes())
        self.program = ctx.program(
            vertex_shader='''
#version 330
in vec2 in_position;
void main() {
    gl_Position = vec4(in_position, 0.0, 1.0);
}
''',
            fragment_shader='''
#version 330
out vec4 fragColor;
void main() {
    fragColor = vec4(0.2, 0.8, 0.3, 1.0);
}
'''
        )
        self.vao = ctx.vertex_array(
            self.program,
            [(self.vbo, '2f', 'in_position')]
        )

    def render(self, ctx):
        self.vao.render(moderngl.TRIANGLES)

    def update(self):
        pass  # No dynamic update needed for static triangle

if __name__ == "__main__":
    window = ApplicationWindow(width=800, height=600, title="Triangle VizCore")
    renderer = Renderer(window.ctx)
    triangle = TriangleWidget(window.ctx)
    window.widgets = [triangle]

    # Override window's on_draw to use Renderer
    def on_draw():
        window.clear()
        renderer.begin_frame()
        triangle.render(window.ctx)
        renderer.end_frame()
    window.on_draw = on_draw

    pyglet.app.run()