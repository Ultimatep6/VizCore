import pyglet

class MainLoop:
    """
    Controls the render/update loop.

    Responsibilities:
        - Maintain stable frame rate
        - Update widgets
        - Submit draw calls

    Typical loop responsibilities:
        1. Poll window events
        2. Update widgets
        3. Execute rendering pass
    """
    def __init__(self, window, widgets, target_fps=60):
        self.window = window
        self.widgets = widgets
        self.target_fps = target_fps

    def update(self, dt):
        # Update all widgets with new data
        for widget in self.widgets:
            widget.update()
        # Redraw window
        self.window.dispatch_event('on_draw')

    def run(self):
        pyglet.clock.schedule_interval(self.update, 1.0 / self.target_fps)
        pyglet.app.run()