class BaseWidget:
    """
    Abstract widget class.

    Responsibilities:
        - Define widget interface
        - Store widget rectangle
        - Maintain widget state

    All widgets must implement:
        - update(data)
        - draw(renderer)
        - resize(rect)
    """
    def __init__(self, rect):
        self.rect = rect
        self.state = {}

    def update(self, data):
        raise NotImplementedError("update() must be implemented by subclass")

    def draw(self, renderer):
        raise NotImplementedError("draw() must be implemented by subclass")

    def resize(self, rect):
        self.rect = rect